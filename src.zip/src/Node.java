public class Node<T> {
    private T data;
    private Node<T> next;

    public T getData(){
        return data;
    }

    public void setData(T data){
        this.data = data;
    }

    public Node<T> getNext(){
        return next;
    }

    public void setNext(Node<T> node){
        this.next = node;
    }

}
